import React from 'react';

const TableauFrame = () => {
  return (
    <div>
      {/* Place your Tableau iframe here */}
    </div>
  );
};

export default TableauFrame;
